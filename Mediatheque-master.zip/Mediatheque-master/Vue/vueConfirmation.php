<?php
/**
 * Created by PhpStorm.
 * User: 59013-76-04
 * Date: 17/07/2018
 * Time: 15:02
 */
$this->titre = "Bonne Chope";
$this->script = '';

echo "<h3>$message</h3>";

header("refresh:5;url=index.php");
?>