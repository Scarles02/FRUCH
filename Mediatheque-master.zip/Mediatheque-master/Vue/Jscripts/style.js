$(function() {
    $('#stickymenu').puimenubar();

    $('#stickymenu').parent().puisticky();
});