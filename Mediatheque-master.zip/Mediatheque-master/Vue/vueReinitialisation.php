<?php
/**
 * Created by PhpStorm.
 * User: 59013-76-04
 * Date: 18/07/2018
 * Time: 08:05
 */

$this->titre ="VueReinitialisation";
$this->script = '<script src="Vue/Jscripts/identification.js" type="text/javascript"></script>';

echo "$message";

?>