<?php
/**
 * Created by PhpStorm.
 * User: 59013-76-04
 * Date: 16/07/2018
 * Time: 09:39
 */
$this->titre = "Identification";
$this->script ='<script src="Vue/Jscripts/identification.js" type="text/javascript"></script>';

echo '<script>identification()</script>';
?>