Exemple d'une gestion d'objet
     
     php - ajax - jquery

http://mediatheque.boucham-amine.fr/  
username : invite
password : Invite1!

Ou vous pouvez vous créer un compte
