<?php
	
	class DaoEditeur
	{
		public function getAllEditeurs()
		{
			require_once 'SqlConnect.php';
			$sql = new SqlConnect();
			
			// Récupération de l'instance de la classe PDO
			$pdo    = $sql->getConnexion();
			$result = $pdo->prepare('SELECT * FROM editeur');
			$result->execute();
			while ( $r = $result->fetch() )
			{
				$retour[] = $this->dataToEditeur($r);
			}
			return $retour;
		}
		
		public static function ajoutEditeur( $nom )
		{
			require_once 'SqlConnect.php';
			$sql = new SqlConnect();
			
			// Récupération de l'instance de la classe PDO
			$pdo    = $sql->getConnexion();
			$result = $pdo->prepare('INSERT INTO editeur (nom) VALUES (:nom)');
			$result->bindValue(':nom', "$nom");
			$result->execute();
		}
		
		// Convertit en une instance de notre Modèle
		function dataToEditeur( $r )
		{
			$resultat = new Editeur();
			$resultat->setId($r[0]);
			$resultat->setNom($r[1]);
			return $resultat;
		}
		
		public function getEditeursByExample($recherche) {
			// Préparation de la requête
			
			//$couleur = $recherche->couleur;
			//$type = $recherche->type;
			
			$fetch = $recherche->lignesParPages;
			$offset = max(0, $recherche->numPage  * $fetch);
			
			$order = " order by id_editeur limit $offset ,$fetch";
			
			$clauseWhere = " where nom LIKE :nom";
			/*if ($couleur != 0)
				$clauseWhere .= " and ID_COULEUR = $couleur";
			if ($type != 0)
				$clauseWhere .= " and ID_TYPE = $type";*/
			
			$nom = "";
			$result = $this->pdo->prepare("select count(*) from editeur" . $clauseWhere);
			$result->bindValue(':nom', '%' . $nom . '%');
			// Exécution de la requête
			$result->execute();
			if ($result) {
				$row = $result->fetch();
				$total = $row[0];
				$result = $this->pdo->prepare("SELECT * FROM editeur" . $clauseWhere . $order);
				$result->bindValue(':nom', '%' . $nom . '%');
				// Exécution de la requête
				$result->execute();
				$editeurs = array ();
				while ($r = $result->fetch()) {
					$editeurs[] = $this->dataToEditeur($r);
				}
			}
			$retour['editeur'] = $editeurs;
			$recherche->total = $total;
			return $retour['editeur'];
		}
	}