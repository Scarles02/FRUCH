<?php
	
	class SqlConnect
	{
		private $connexion_bdd;
		
		function __construct()
		{
			$localhost = array(
				'127.0.0.1',
				'::1'
			);
			
			try
			{
				if ( in_array($_SERVER['REMOTE_ADDR'], $localhost) )
				{
					// Créé une instance de la classe PDO MySQL Local
					$this->connexion_bdd = new PDO('mysql:host=localhost;dbname=mediatheque', 'root', '', array( PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8' ));
				}
				else
				{
					// Créé une instance de la classe PDO MySQL Distante
					//$this->connexion_bdd = new PDO('mysql:host=5.135.240.0;dbname=mediatheque', 'root', 'root', array( PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8' ));
				}
				
				// Créé une instance de la classe PDO MySQL Serveur free
				//$this->connexion_bdd =  new PDO('mysql:host=sql.free.fr;dbname=fsackebandt','fsackebandt','xxxxxxxxx',array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
				
				// Fixe les options d'erreur (ici nous utiliserons les exceptions)
				$this->connexion_bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			}
			catch (PDOException $exception)
			{
				var_dump($exception);
			}
		}
		
		// Créé un accesseur sur la connexion à la BDD
		public function getConnexion()
		{
			// Permet d'accéder à l'instance de la connexion à la base de données
			return $this->connexion_bdd;
		}
	}
