<?php
	
	class ControleurAjoutEditeur
	{
		private $editeur;
		
		public function __construct()
		{
			$this->editeur = new DaoEditeur();
		}
		
		public function controle()
		{
			$vue = new Vue("AjoutEditeur");
			$vue->generer(array());
			
			if ( !empty($_POST) )
			{
				$this->editeur->ajoutEditeur($_POST['textNomEditeur']);
			}
		}
	}