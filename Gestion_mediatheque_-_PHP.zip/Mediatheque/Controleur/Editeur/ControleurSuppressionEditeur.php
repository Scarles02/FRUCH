<?php
	
	class ControleurSuppressionEditeur
	{
		public function controle()
		{
			$vue = new Vue("SuppressionEditeur");
			$vue->generer(array());
		}
	}