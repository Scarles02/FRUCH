<?php
	
	class ControleurModificationEditeur
	{
		private $editeur;
		private $recherche;
		
		public function __construct( $recherche )
		{
			$this->editeur   = new DaoEditeur();
			$this->recherche = $recherche;
			$this->litParametres($recherche);
		}
		
		public function controle()
		{
			//$editeurs = json_encode($this->editeur->getAllEditeurs());
			$vue = new Vue("ModificationEditeur");
			$vue->generer(array( /*'editeurs' => $editeurs,*/  'recherche' => json_encode($this->recherche) ));
		}
		
		private function litParametres($post)
		{
			$this->recherche = new stdClass();
			$temp = OutilsControleur::getParametre($post, 'lignesParPages');
			
			if ($temp != 0)
				$_SESSION['lignesParPages'] = $temp;
			$this->recherche->lignesParPages = OutilsControleur::getParametre($_SESSION, 'lignesParPages');
			$this->recherche->numPage = OutilsControleur::getParametre($post, 'numPage');
		}
	}