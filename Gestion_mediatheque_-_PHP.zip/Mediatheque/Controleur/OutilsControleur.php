<?php
	
	class OutilsControleur
	{
		// Recherche un paramètre dans un tableau
		public static function getParametre( $tableau, $nom )
		{
			if ( isset($tableau[$nom]) )
			{
				return $tableau[$nom];
			}
			else
			{
				return '0';
			}
		}
		
	}