<?php
	
	class ControleurEditeur
	{
		public function controle()
		{
			$vue = new Vue("Editeur");
			$vue->generer(array());
		}
	}