<?php

	class ControleurAccueil
	{
		public function controle()
		{
			$vue = new Vue("Accueil");
			$vue->generer(array());
		}
	}