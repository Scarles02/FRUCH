<?php
	
	class ControleurRechercheOeuvre
	{
		public function controle()
		{
			$vue = new Vue("RechercheOeuvre");
			$vue->generer(array());
		}
	}