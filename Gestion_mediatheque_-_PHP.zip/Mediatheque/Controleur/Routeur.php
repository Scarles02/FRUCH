<?php
	
	// Déclaration de la Classe Routeur
	class Routeur
	{
		private $controleur;
		
		public function __construct()
		{
			if ( OutilsControleur::getParametre($_SESSION, 'lignesParPages') == 0 )
			{
				$_SESSION['lignesParPages'] = 10;
			}
		}
		
		public function routerRequete()
		{
			if ( !isset($_GET['action']) ) $_GET['action'] = "Accueil";
			
			if ( !strpos($_GET['action'], '-') )
			{
				$controleur = 'Controleur'.$_GET['action'];
			}
			else
			{
				$segementsGetAction = explode('-', $_GET['action']);
				$controleur         = 'Controleur'.$segementsGetAction[1];
			}
			
			$param = $_POST;
			
			$this->controleur = new $controleur($param);
			$this->controleur->controle();
		}
		
		
	}