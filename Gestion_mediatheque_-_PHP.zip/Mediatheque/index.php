<?php
	session_start();
	require_once 'autorequire.php';
	
	$routeur = new Routeur();
	$routeur->routerRequete();