<?php
	
	class AutoRequireAjax
	{
		
		public static function loadClass( $class )
		{
			$directory = '';
			
			if ( isset($_GET['action']) )
			{
				if ( strpos($_GET['action'], '-') )
				{
					$segementsGetAction = explode('-', $_GET['action']);
					$directory          = $segementsGetAction[0];
				}
			}
			
			if ( file_exists("$class.php") )
			{
				require_once "$class.php";
			}
			else if ( file_exists("../$class.php") )
			{
				require_once "../$class.php";
			}
			else if ( file_exists("../Controleur/$class.php") )
			{
				require_once "../Controleur/$class.php";
			}
			else if ( file_exists("Controleur/".$directory."/$class.php") )
			{
				require_once "Controleur/".$directory."/$class.php";
			}
			else if ( file_exists("../Model/Metier/$class.php") )
			{
				require_once "../Model/Metier/$class.php";
			}
			else if ( file_exists("../Model/DAO/$class.php") )
			{
				require_once "../Model/DAO/$class.php";
			}
			else if ( file_exists("../Vue/$class.php") )
			{
				require_once "../Vue/$class.php";
			}
			else if (file_exists("Vue/".$directory."/vue".$class.".php"))
			{
				require_once "../Vue/".$directory."/vue".$class.".php";
			}
			/*else if ( file_exists("../phpmailer/$class.php") )
			{
				require_once "../phpmailer/$class.php";
			}*/
		}
	}
	
	spl_autoload_register('AutoRequireAjax::loadClass');
?>

