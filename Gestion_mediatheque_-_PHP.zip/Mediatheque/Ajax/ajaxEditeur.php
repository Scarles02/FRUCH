<script type = "text/javascript">
	alert("hautajaxediteur");
</script>

<?php

	// Démarrage de la session
	session_start();
	
	require 'AutoRequireAjax.php';
	
	// on créé une instance de la classe DAO
	$maDao = new DaoEditeur();
	
	// On créé un objet recherche
	$recherche = new stdClass();
	
	// On récupère les différents critères de recherche dans le tableau associatif $_POST
	//$recherche->couleur        = OutilsControleur::getParametre($_POST, 'couleur');
	//$recherche->type           = getParametre($_POST, 'type');
	$recherche->lignesParPages = max(10, getParametre($_POST, 'lignesParPages'));
	$recherche->numPage        = getParametre($_POST, 'numPage');
	
	// On récupère les enregistrements correspondants aux critères dans le tableau $retour
	$retour = $maDao->getEditeursByExample($recherche);
	
	// On ajoute à la fin du tableau, le nombre total d'enregistrements correspondants aux critères
	$retour[] = $recherche->total;
	
	// on met à jour la variable de session lignesParPage
	$_SESSION['lignesParPages'] = $recherche->lignesParPages;
	
	// on encode le tableau $retour au format JsON
	$json = json_encode($retour);
	
	// On envoie
	echo $json;
	
	function getParametre( $tableau, $nom )
	{
		if ( isset($tableau[$nom]) )
		{
			return $tableau[$nom];
		}
		else
			return 0;
	}

?>

<script type = "text/javascript">
	alert("basajaxediteur");
</script>
