// Gestion des Combos de recherche
/*function afficheCombos(couleurs, types, recherche)
 {
 $(function () {

 $('#comboLignesParPages').puidropdown({
 change: (function () {
 refreshArticles();
 })
 });
 for (item in couleurs)
 {
 $('#comboCouleur').append('<option value="' + couleurs[item].id + '">' + couleurs[item].nom + '</option>');
 }
 for (item in types)
 {
 $('#comboType').append('<option value="' + types[item].id + '">' + types[item].nom + '</option>');
 }

 $('#comboCouleur').puidropdown({
 change: (function () {
 $('input[id="numPage"]').val(0);
 refreshArticles();
 })
 });
 $('#comboType').puidropdown({
 change: (function () {
 $('input[id="numPage"]').val(0);
 refreshArticles();
 })
 });

 $('#comboCouleur').puidropdown('selectValue', recherche.couleur);
 $('#comboType').puidropdown('selectValue', recherche.type);
 $('#comboLignesParPages').puidropdown('selectValue', recherche.lignesParPages);
 });
 }*/


function pagination ()
{
	$ ( function ()
	{
		$ ( "#pag" ).puipaginator ( {
			totalRecords: recherche.total,
			rows: recherche.lignesParPages,
			page: parseInt ( recherche.numPage ),
			pageLinks: 5,
			paginate: function ( event, state )
			{
				if ( state.page != recherche.numPage )
				{
					$ ( "input[id=\"numPage\"]" ).val ( state.page );
					refreshEditeurs ();
				}
			}
		} );
	} );
}

function refreshEditeurs ()
{
	alert ( "refreshediteurs" );
	// récupération des critères de recherche
	recherche = new Object ();
	//recherche.couleur = $('#comboCouleur option:selected').val();
	//recherche.type = $('#comboType option:selected').val();
	recherche.numPage = $ ( "#numPage" ).val ();
	recherche.lignesParPages = 10/*$('#comboLignesParPages option:selected').val()*/;
	recherche.total = $ ( "#total" ).val ();
	alert ( "avantajax" );
	// Requete AJAX
	try
	{
		$.ajax ( {
			// url du programme à executer
			url: "Ajax/ajaxEditeur.php",
			// type d'envoi des paramètres ('POST' ou 'GET')
			type: "POST",
			// Données envoyées avec la requête
			data: recherche,
			// Format du retour
			dataType: "json",
			// En cas de réussite
			// la variable retour est un array qui contiendra le résultat envoyé par le programme ajaxArticle.php
			success: function ( retour )
			{
				alert ( "successrefreshediteurs" );
				// On recupère le nombre total d'enregistrements correspondants à la requête
				recherche.total = retour[ retour.length - 1 ];
				$ ( "#nbEditeur" ).html ( "Editeurs (" + recherche.total + ")" );
				// On met à jour le champ caché d'Id total
				$ ( "input[id=\"total\"]" ).val ( recherche.total );
				// on supprime toutes les lignes (tr) qui sont parentes des lignes de detail du tableau d'Id tableArtiste
				$ ( "#tableEditeur td" ).parent ( "tr" ).remove ();
				// On Actualise la pagination
				pagination ();
				alert ( "pagination" );
				// On balaie tous les éléments du tableau retour

				if ( retour.length == 1 )
				{
					$ ( "#tableEditeur" ).append ( "<tr><td colspan=\"4\" align=\"center\"><b>Désolé aucun editeur ne correspond à votre sélection.</td></tr>" );
				}
				else
				{
					for ( i = 0; i < retour.length - 1; i++ )
					{
						// e = editeur
						e = retour[ i ];
						// On prépare la ligne de détail
						ligne = "<tr><td>" + e.id + "</td><td>" + e.nom + "</td></tr>";
						// on ajoute la ligne de détail au tableau tableArtiste
						$ ( "#tableEditeur" ).append ( ligne );
					}
				}
			},
			error: function ()
			{
				alert ( "erreurajax" );
			}
		} );
	}
	catch ( err )
	{
		document.getElementById ( "contenu" ).innerHTML = err.message;
	}
}