var couleurSelected = new Object ();

function afficheTableau ( src, ancre )
{

	couleurSelected.id = 0;

	$ ( function ()
	{
		$ ( ancre ).puidatatable ( {
			caption: "Résultat de la Requête DAO",
			paginator: {
				rows: 10
			},
			columns: [
				{ field: "id", headerText: "Id", sortable: true },
				{ field: "nom", headerText: "Nom", sortable: true }
			],
			datasource: src,
			selectionMode: "single",
			rowSelect: function ( event, data )
			{
				$ ( "#messages" ).puigrowl ( "show", [ {
					severity: "info",
					summary: "Row Selected",
					detail: ( couleurSelected.id + " -> " + data.id + " " + data.nom )
				} ] );
				couleurSelected = data;
				$ ( "#btModifier" ).prop ( "disabled", false );
				$ ( "#btSupprimer" ).prop ( "disabled", false );

				$ ( "#btModifier" ).click ( function ()
				{
					$ ( "#gestionBackground" ).fadeIn ();

					$ ( "#gestionBackground" ).append ( "<div id='gestionWindow'>" +
						"<input id='idElement' name='idElement' type='text' value=" + data.id + " />" +
						"<input id='nomElement' name='nomElement' type='text' value=" + data.nom + " />" +
						"<input id='btConfirmer' name='btConfirmer' type='button' value='Confirmer' />" +
						"<input id='btAnnuler' name='btAnnuler' type='button' value='Annuler' />" +
						"</div>" );

					$ ( "#btConfirmer" ).click ( function ()
					{
						alert(data.id + " " + data.nom);
					} );

					$ ( "#btAnnuler" ).click ( function ()
					{
						$ ( "#gestionBackground" ).fadeOut ( function ()
						{
							$ ( "#gestionBackground" ).empty ();
						} );
					} );
				} );
			},
			rowUnselect: function ( event, data )
			{
				$ ( "#messages" ).puigrowl ( "show", [ {
					severity: "info",
					summary: "Row Unselected",
					detail: ( data.id + " " + data.nom )
				} ] );
				$ ( "#btModifier" ).prop ( "disabled", true );
				$ ( "#btSupprimer" ).prop ( "disabled", true );
			}
		} );
		$ ( "#messages" ).puigrowl ();
	} );

	$ ( "#btAjouter" ).click ( function ()
	{
		$ ( "#gestionBackground" ).fadeIn ();

		$ ( "#gestionBackground" ).append ( "<div id='gestionWindow'>" +
			"<input id='idElement' name='idElement' type='text' />" +
			"<input id='nomElement' name='nomElement' type='text' />" +
			"<input id='btConfirmer' name='btConfirmer' type='button' value='Confirmer' />" +
			"<input id='btAnnuler' name='btAnnuler' type='button' value='Annuler' />" +
			"</div>" );

		$ ( "#btConfirmer" ).click ( function ()
		{
			alert("ça fonctionne !");
		} );

		$ ( "#btAnnuler" ).click ( function ()
		{
			$ ( "#gestionBackground" ).fadeOut ( function ()
			{
				$ ( "#gestionBackground" ).empty ();
			} );
		} );
	} );

	$ ( "#btSupprimer" ).click ( function ()
	{
		$ ( "#gestionBackground" ).fadeIn ();

		$ ( "#gestionBackground" ).append ( "<div id='gestionWindow'>" +
			"<input id='btConfirmer' name='btConfirmer' type='button' value='Confirmer' />" +
			"<input id='btAnnuler' name='btAnnuler' type='button' value='Annuler' />" +
			"</div>" );

		$ ( "#btConfirmer" ).click ( function ()
		{
			alert("ça fonctionne !");
		} );

		$ ( "#btAnnuler" ).click ( function ()
		{
			$ ( "#gestionBackground" ).fadeOut ( function ()
			{
				$ ( "#gestionBackground" ).empty ();
			} );
		} );
	} );
}

function afficheSelected ()
{
	alert ( couleurSelected.id + " " + couleurSelected.nom );
}