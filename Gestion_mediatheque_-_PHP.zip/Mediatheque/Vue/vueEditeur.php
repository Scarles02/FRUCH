<?php
	$this->titre = "Gestion des Éditeurs";
?>

</br>
<h1>Editeur</h1>
<a href = "Editeur-AjoutEditeur">Ajouter un Editeur</a><br />
<a href = "Editeur-ModificationEditeur">Modifier un Editeur</a><br />
<a href = "Editeur-SuppressionEditeur">Supprimer un Editeur</a><br />