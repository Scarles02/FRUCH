<?php
	$this->titre = "Rechercher une Oeuvre";
?>

</br>
<h1>Rechercher une Oeuvre</h1>