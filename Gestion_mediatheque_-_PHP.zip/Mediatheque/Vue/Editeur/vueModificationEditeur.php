<?php
	$this->titre  = "Modifier un Éditeur";
	//$this->script = '<script src="Vue/Jscripts/afficheTableau.js" type="text/javascript"></script>';
	$this->script = '<script src="Vue/Jscripts/editeurScript.js" type="text/javascript"></script>';
	
	$rech = json_decode($recherche);
	
	echo '	</br>
			<h1>Modifier un Éditeur</h1>
	
			<input type="hidden" id="total">
			<input type="hidden" value = "0" id="numPage"/>
	
			<div class="matable">
			
				<div id="pag"></div>
				
				<table id="tableEditeur">
					<tr><th class="id">Id</th><th class = "nom" id="nbEditeur">Editeur</th></tr>
				</table>
				
			</div>
	
			<input id="btAjouter" name="btAjouter" type="button" value="Ajouter" />
			<input id="btModifier" name="btModifier" type="button" value="Modifier" disabled="true" />
			<input id="btSupprimer" name="btSupprimer" type="button" value="Supprimer" disabled="true" />';

?>

<script type = "text/javascript">
	alert("Script vue");
	$(document).ready(refreshEditeurs());

	recherche = <?php echo $recherche; ?>;
	//afficheTableau ( scriptData, "#tableau" );
	//afficheCombos(couleurs, types, recherche);
</script>


