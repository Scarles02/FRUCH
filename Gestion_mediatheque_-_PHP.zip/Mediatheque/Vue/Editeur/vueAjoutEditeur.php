<?php
	$this->titre = "Ajouter un Éditeur";
?>

</br>
<h1>Ajouter un Éditeur</h1>

<?php if ( empty($_POST['textNomEditeur']) ){ ?>

	<form action = "Editeur-AjoutEditeur" method = "post">
		<input id = "textNomEditeur" name = "textNomEditeur" type = "text" placeholder = "Nom de l'éditeur" /><br />
		<input id = "btAjoutEditeur" name = "btAjoutEditeur" type = "submit" value = "Ajouter l'éditeur">
	</form>

<?php }else{ ?>

	<p>L'éditeur <?= $_POST['textNomEditeur'] ?> a été ajouté à la base de données.</p>

<?php } ?>
