<?php
	$this->titre = "Supprimer un Éditeur";
?>

</br>
<h1>Supprimer un Éditeur</h1>
